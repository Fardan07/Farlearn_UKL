<?php
session_start();
require 'config.php';

// Tambah ke keranjang
if (isset($_GET['beli'])) {
    $id = $_GET['beli'];
    $result = $koneksi->query("SELECT * FROM buku WHERE id=$id");
    $buku = $result->fetch_assoc();

    $_SESSION['keranjang'][$id] = $buku;
    header("Location: crud.php");
    exit;
}

// Hapus satu item
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    unset($_SESSION['keranjang'][$id]);
    header("Location: crud.php");
    exit;
}

// Kosongkan keranjang
if (isset($_GET['batal'])) {
    unset($_SESSION['keranjang']);
    header("Location: crud.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>CRUD Toko Buku</title>
    <link rel="stylesheet" href="crud.css">
</head>
<body>
    <h2>Daftar Buku</h2>
    <div class="book-list">
        <?php
        $result = $koneksi->query("SELECT * FROM buku");
        while ($buku = $result->fetch_assoc()):
        ?>
        <div class="card">
            <img src="uploads/<?= $buku['gambar'] ?>" alt="<?= $buku['judul'] ?>">
            <h3><?= $buku['judul'] ?></h3>
            <p><?= $buku['penulis'] ?></p>
            <p>Rp <?= number_format($buku['harga']) ?></p>
            <a href="?beli=<?= $buku['id'] ?>" class="btn">Beli</a>
        </div>
        <?php endwhile; ?>
    </div>

    <h2>Keranjang Belanja</h2>
    <?php if (!empty($_SESSION['keranjang'])): ?>
        <table>
            <thead>
                <tr>
                    <th>Judul</th><th>Penulis</th><th>Harga</th><th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($_SESSION['keranjang'] as $item): ?>
                    <tr>
                        <td><?= $item['judul'] ?></td>
                        <td><?= $item['penulis'] ?></td>
                        <td>Rp <?= number_format($item['harga']) ?></td>
                        <td><a href="?hapus=<?= $item['id'] ?>" class="btn danger">Batal</a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <a href="?batal=1" class="btn danger">Batal Semua</a>
    <?php else: ?>
        <p>Keranjang kosong.</p>
    <?php endif; ?>
</body>
</html>
